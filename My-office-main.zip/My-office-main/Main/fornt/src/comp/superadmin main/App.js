import React, { useState, useEffect } from 'react';

// Dummy Data
const dummyEmployees = [
  {
    id: 'emp001',
    name: 'Alice Johnson',
    email: 'alice.j@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 09:00 AM', '2025-07-14 06:00 PM'],
    logoutTimes: ['2025-07-14 05:00 PM', '2025-07-14 06:30 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-001',
    isIntern: false,
    birthday: '1990-08-15',
    workSchedule: 'Mon-Fri, 9 AM - 5 PM',
    leaveStatus: 'Approved (2 days)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Welcome to the team!', timestamp: '2025-07-01 10:00 AM' },
    ],
  },
  {
    id: 'emp002',
    name: 'Bob Williams',
    email: 'bob.w@example.com',
    status: 'Inactive',
    loginTimes: ['2025-07-10 08:30 AM'],
    logoutTimes: ['2025-07-10 04:30 PM'],
    attendance: { '2025-07-14': 'Absent', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-002',
    isIntern: true,
    birthday: '2000-03-22',
    workSchedule: 'Mon-Fri, 10 AM - 6 PM',
    leaveStatus: 'Pending (1 day)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Please submit your report.', timestamp: '2025-07-12 02:00 PM' },
    ],
  },
  {
    id: 'emp003',
    name: 'Charlie Brown',
    email: 'charlie.b@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 09:15 AM'],
    logoutTimes: ['2025-07-14 05:15 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-003',
    isIntern: false,
    birthday: '1995-11-01',
    workSchedule: 'Mon-Fri, 9 AM - 5 PM',
    leaveStatus: 'None',
    messages: [],
  },
  {
    id: 'emp004',
    name: 'Diana Prince',
    email: 'diana.p@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 08:45 AM'],
    logoutTimes: ['2025-07-14 04:45 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-004',
    isIntern: true,
    birthday: '2001-01-20',
    workSchedule: 'Mon-Fri, 9:30 AM - 5:30 PM',
    leaveStatus: 'Approved (5 days)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Internship certificate ready for collection.', timestamp: '2025-07-10 11:00 AM' },
    ],
  },
];

// Reusable Card Component
const Card = ({ title, children }) => (
  <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
    <h3 className="text-xl font-semibold text-gray-800 mb-4">{title}</h3>
    {children}
  </div>
);

// Employee Details Component
const EmployeeDetails = ({ employees }) => (
  <Card title="All Employee Details">
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg overflow-hidden">
        <thead className="bg-teal-700 text-white">
          <tr>
            <th className="py-3 px-4 text-left">ID</th>
            <th className="py-3 px-4 text-left">Name</th>
            <th className="py-3 px-4 text-left">Email</th>
            <th className="py-3 px-4 text-left">Status</th>
            <th className="py-3 px-4 text-left">Intern</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
              <td className="py-3 px-4">{emp.id}</td>
              <td className="py-3 px-4">{emp.name}</td>
              <td className="py-3 px-4">{emp.email}</td>
              <td className={`py-3 px-4 font-medium ${emp.status === 'Active' ? 'text-green-600' : 'text-red-600'}`}>
                {emp.status}
              </td>
              <td className="py-3 px-4">{emp.isIntern ? 'Yes' : 'No'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

// Login & Logout Time Component
const LoginLogoutTime = ({ employees }) => (
  <Card title="Login & Logout Times">
    {employees.map((emp) => (
      <div key={emp.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
        <h4 className="font-semibold text-gray-700">{emp.name} ({emp.id})</h4>
        <p className="text-sm text-gray-600"><strong>Login:</strong> {emp.loginTimes.join(', ') || 'N/A'}</p>
        <p className="text-sm text-gray-600"><strong>Logout:</strong> {emp.logoutTimes.join(', ') || 'N/A'}</p>
      </div>
    ))}
  </Card>
);

// Update Status Component
const UpdateStatus = ({ employees, onUpdateStatus }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [newStatus, setNewStatus] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedEmployeeId && newStatus) {
      onUpdateStatus(selectedEmployeeId, newStatus);
      setSelectedEmployeeId('');
      setNewStatus('');
    }
  };

  return (
    <Card title="Update Employee Status">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="employeeSelect" className="block text-sm font-medium text-gray-700 mb-1">Select Employee:</label>
          <select
            id="employeeSelect"
            value={selectedEmployeeId}
            onChange={(e) => setSelectedEmployeeId(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select Employee --</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="statusSelect" className="block text-sm font-medium text-gray-700 mb-1">New Status:</label>
          <select
            id="statusSelect"
            value={newStatus}
            onChange={(e) => setNewStatus(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select Status --</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
            <option value="On Leave">On Leave</option>
          </select>
        </div>
        <button
          type="submit"
          className="w-full bg-teal-700 text-white py-2 px-4 rounded-md hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
        >
          Update Status
        </button>
      </form>
    </Card>
  );
};

// Attendance Component
const Attendance = ({ employees }) => {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  return (
    <Card title="Daily Attendance">
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-lg overflow-hidden">
          <thead className="bg-teal-700 text-white">
            <tr>
              <th className="py-3 px-4 text-left">Employee Name</th>
              <th className="py-3 px-4 text-left">Date</th>
              <th className="py-3 px-4 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
                <td className="py-3 px-4">{emp.name}</td>
                <td className="py-3 px-4">{today}</td>
                <td className={`py-3 px-4 font-medium ${emp.attendance[today] === 'Present' ? 'text-green-600' : 'text-red-600'}`}>
                  {emp.attendance[today] || 'N/A'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

// Invoice of Salary Component
const SalaryInvoice = ({ employees }) => (
  <Card title="Salary Invoices">
    {employees.map((emp) => (
      <div key={emp.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
        <h4 className="font-semibold text-gray-700">{emp.name} ({emp.id})</h4>
        <p className="text-sm text-gray-600"><strong>Invoice ID:</strong> {emp.salaryInvoice || 'N/A'}</p>
        <button className="mt-2 bg-cyan-500 text-white py-1 px-3 rounded-md text-sm hover:bg-cyan-600 transition-colors duration-200">
          View Invoice
        </button>
      </div>
    ))}
  </Card>
);

// Certificate for Intern Component
const InternCertificate = ({ employees }) => {
  const interns = employees.filter(emp => emp.isIntern);
  return (
    <Card title="Intern Certificates">
      {interns.length > 0 ? (
        interns.map((intern) => (
          <div key={intern.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
            <h4 className="font-semibold text-gray-700">{intern.name} ({intern.id})</h4>
            <p className="text-sm text-gray-600">Internship Period: Jan 2025 - Jul 2025</p>
            <button className="mt-2 bg-cyan-500 text-white py-1 px-3 rounded-md text-sm hover:bg-cyan-600 transition-colors duration-200">
              Generate Certificate
            </button>
          </div>
        ))
      ) : (
        <p className="text-gray-600">No interns found.</p>
      )}
    </Card>
  );
};

// Birthday Date Component
const BirthdayDate = ({ employees }) => {
  const today = new Date();
  const currentMonth = today.getMonth() + 1; // getMonth() is 0-indexed
  const currentDay = today.getDate();

  const upcomingBirthdays = employees.filter(emp => {
    const [year, month, day] = emp.birthday.split('-').map(Number);
    return (month === currentMonth && day >= currentDay) || (month > currentMonth);
  }).sort((a, b) => {
    const [aY, aM, aD] = a.birthday.split('-').map(Number);
    const [bY, bM, bD] = b.birthday.split('-').map(Number);
    if (aM !== bM) return aM - bM;
    return aD - bD;
  });

  return (
    <Card title="Upcoming Birthdays">
      {upcomingBirthdays.length > 0 ? (
        <ul className="list-disc pl-5 space-y-2">
          {upcomingBirthdays.map((emp) => (
            <li key={emp.id} className="text-gray-700">
              {emp.name} - {new Date(emp.birthday).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-600">No upcoming birthdays this month.</p>
      )}
    </Card>
  );
};

// Work Schedule Component
const WorkSchedule = ({ employees }) => (
  <Card title="Work Schedules">
    {employees.map((emp) => (
      <div key={emp.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
        <h4 className="font-semibold text-gray-700">{emp.name} ({emp.id})</h4>
        <p className="text-sm text-gray-600"><strong>Schedule:</strong> {emp.workSchedule || 'N/A'}</p>
      </div>
    ))}
  </Card>
);

// Google Meet Request Component
const GoogleMeetRequest = ({ employees }) => {
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [meetTopic, setMeetTopic] = useState('');
  const [message, setMessage] = useState(''); // State for custom message box

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedEmployee && meetTopic) {
      // In a real app, this would integrate with Google Meet API
      console.log(`Google Meet request for ${selectedEmployee} on topic: ${meetTopic}`);
      setMessage(`Google Meet request sent to ${selectedEmployee} for "${meetTopic}"`);
      setSelectedEmployee('');
      setMeetTopic('');
    }
  };

  return (
    <Card title="Send Google Meet Request">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="meetEmployee" className="block text-sm font-medium text-gray-700 mb-1">Select Employee:</label>
          <select
            id="meetEmployee"
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select Employee --</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.name}>{emp.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="meetTopic" className="block text-sm font-medium text-gray-700 mb-1">Meeting Topic:</label>
          <input
            type="text"
            id="meetTopic"
            value={meetTopic}
            onChange={(e) => setMeetTopic(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="e.g., Project Discussion"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-teal-700 text-white py-2 px-4 rounded-md hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
        >
          Send Meet Request
        </button>
      </form>
      {message && (
        <div className="mt-4 p-3 bg-green-100 text-green-800 rounded-md">
          {message}
          <button onClick={() => setMessage('')} className="ml-4 text-green-600 font-bold">X</button>
        </div>
      )}
    </Card>
  );
};

// Data Request Component
const DataRequest = ({ employees }) => {
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [dataNeeded, setDataNeeded] = useState('');
  const [message, setMessage] = useState(''); // State for custom message box

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedEmployee && dataNeeded) {
      console.log(`Data request for ${selectedEmployee}: ${dataNeeded}`);
      setMessage(`Data request sent to ${selectedEmployee} for: "${dataNeeded}"`);
      setSelectedEmployee('');
      setDataNeeded('');
    }
  };

  return (
    <Card title="Request Data from Employee">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="dataEmployee" className="block text-sm font-medium text-gray-700 mb-1">Select Employee:</label>
          <select
            id="dataEmployee"
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select Employee --</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.name}>{emp.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="dataNeeded" className="block text-sm font-medium text-gray-700 mb-1">Data Needed:</label>
          <textarea
            id="dataNeeded"
            value={dataNeeded}
            onChange={(e) => setDataNeeded(e.target.value)}
            rows="3"
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="e.g., Latest project report, Expense receipts"
            required
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-teal-700 text-white py-2 px-4 rounded-md hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
        >
          Send Data Request
        </button>
      </form>
      {message && (
        <div className="mt-4 p-3 bg-green-100 text-green-800 rounded-md">
          {message}
          <button onClick={() => setMessage('')} className="ml-4 text-green-600 font-bold">X</button>
        </div>
      )}
    </Card>
  );
};

// Leave Status Component
const LeaveStatus = ({ employees }) => (
  <Card title="Employee Leave Status">
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg overflow-hidden">
        <thead className="bg-teal-700 text-white">
          <tr>
            <th className="py-3 px-4 text-left">Employee Name</th>
            <th className="py-3 px-4 text-left">Leave Status</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
              <td className="py-3 px-4">{emp.name}</td>
              <td className={`py-3 px-4 font-medium ${emp.leaveStatus.includes('Approved') ? 'text-green-600' : emp.leaveStatus.includes('Pending') ? 'text-yellow-600' : 'text-gray-600'}`}>
                {emp.leaveStatus || 'N/A'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

// Message Box Component
const MessageBox = ({ employees, onSendMessage }) => {
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [messageText, setMessageText] = useState('');
  const [message, setMessage] = useState(''); // State for custom message box

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedEmployee && messageText) {
      onSendMessage(selectedEmployee, messageText);
      setMessage(`Message sent to employee ${selectedEmployee}`);
      setSelectedEmployee('');
      setMessageText('');
    }
  };

  return (
    <Card title="Send Message to Employee">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="messageEmployee" className="block text-sm font-medium text-gray-700 mb-1">Select Employee:</label>
          <select
            id="messageEmployee"
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm rounded-md shadow-sm"
          >
            <option value="">-- Select Employee --</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="messageText" className="block text-sm font-medium text-gray-700 mb-1">Message:</label>
          <textarea
            id="messageText"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            rows="4"
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="Type your message here..."
            required
          ></textarea>
        </div>
        <button
          type="submit"
          className="w-full bg-teal-700 text-white py-2 px-4 rounded-md hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
        >
          Send Message
        </button>
      </form>
      {message && (
        <div className="mt-4 p-3 bg-green-100 text-green-800 rounded-md">
          {message}
          <button onClick={() => setMessage('')} className="ml-4 text-green-600 font-bold">X</button>
        </div>
      )}
      <div className="mt-6">
        <h4 className="text-lg font-semibold text-gray-800 mb-3">Recent Messages:</h4>
        {employees.some(emp => emp.messages && emp.messages.length > 0) ? (
          employees.map(emp => emp.messages && emp.messages.length > 0 && (
            <div key={emp.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
              <h5 className="font-semibold text-gray-700">{emp.name}'s Messages:</h5>
              {emp.messages.map(msg => (
                <div key={msg.id} className="text-sm text-gray-600 mt-1">
                  <span className="font-medium">{msg.sender}:</span> {msg.text} <span className="text-xs text-gray-400">({msg.timestamp})</span>
                </div>
              ))}
            </div>
          ))
        ) : (
          <p className="text-gray-600">No messages sent yet.</p>
        )}
      </div>
    </Card>
  );
};


// Dashboard Component
const Dashboard = ({ employees }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <Card title="Total Employees">
      <p className="text-5xl font-bold text-teal-600">{employees.length}</p>
    </Card>
    <Card title="Active Employees">
      <p className="text-5xl font-bold text-green-600">
        {employees.filter(emp => emp.status === 'Active').length}
      </p>
    </Card>
    <Card title="Interns">
      <p className="text-5xl font-bold text-purple-600">
        {employees.filter(emp => emp.isIntern).length}
      </p>
    </Card>
    <Card title="Attendance Today">
      <p className="text-5xl font-bold text-yellow-600">
        {employees.filter(emp => emp.attendance[new Date().toISOString().slice(0, 10)] === 'Present').length} / {employees.length}
      </p>
    </Card>
    <Card title="Pending Leaves">
      <p className="text-5xl font-bold text-red-600">
        {employees.filter(emp => emp.leaveStatus.includes('Pending')).length}
      </p>
    </Card>
    <Card title="Recent Activity">
      <ul className="list-disc pl-5 text-gray-700">
        <li>Alice Johnson logged in.</li>
        <li>Bob Williams updated status.</li>
        <li>New leave request from Charlie Brown.</li>
      </ul>
    </Card>
  </div>
);

// Main App Component
function App() {
  const [employees, setEmployees] = useState(dummyEmployees);
  const [currentPage, setCurrentPage] = useState('dashboard'); // State to manage current page view
  const [message, setMessage] = useState(''); // State for custom message box

  // Function to handle status update
  const handleUpdateStatus = (employeeId, newStatus) => {
    setEmployees(prevEmployees =>
      prevEmployees.map(emp =>
        emp.id === employeeId ? { ...emp, status: newStatus } : emp
      )
    );
    setMessage(`Status for employee ${employeeId} updated to ${newStatus}`);
  };

  // Function to handle sending messages
  const handleSendMessage = (employeeId, messageText) => {
    setEmployees(prevEmployees =>
      prevEmployees.map(emp =>
        emp.id === employeeId
          ? {
              ...emp,
              messages: [
                ...(emp.messages || []),
                { id: emp.messages ? emp.messages.length + 1 : 1, sender: 'Super Admin', text: messageText, timestamp: new Date().toLocaleString() }
              ]
            }
          : emp
      )
    );
    setMessage(`Message sent to employee ${employeeId}`);
  };

  // Navigation items
  const navItems = [
    { name: 'Dashboard', component: 'dashboard' },
    { name: 'Employee Details', component: 'employeeDetails' },
    { name: 'Login & Logout', component: 'loginLogout' },
    { name: 'Update Status', component: 'updateStatus' },
    { name: 'Attendance', component: 'attendance' },
    { name: 'Salary Invoice', component: 'salaryInvoice' },
    { name: 'Intern Certificate', component: 'internCertificate' },
    { name: 'Birthday Date', component: 'birthdayDate' },
    { name: 'Work Schedule', component: 'workSchedule' },
    { name: 'Google Meet Request', component: 'googleMeetRequest' },
    { name: 'Data Request', component: 'dataRequest' },
    { name: 'Leave Status', component: 'leaveStatus' },
    { name: 'Message Box', component: 'messageBox' },
  ];

  // Render the current page component based on currentPage state
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard employees={employees} />;
      case 'employeeDetails':
        return <EmployeeDetails employees={employees} />;
      case 'loginLogout':
        return <LoginLogoutTime employees={employees} />;
      case 'updateStatus':
        return <UpdateStatus employees={employees} onUpdateStatus={handleUpdateStatus} />;
      case 'attendance':
        return <Attendance employees={employees} />;
      case 'salaryInvoice':
        return <SalaryInvoice employees={employees} />;
      case 'internCertificate':
        return <InternCertificate employees={employees} />;
      case 'birthdayDate':
        return <BirthdayDate employees={employees} />;
      case 'workSchedule':
        return <WorkSchedule employees={employees} />;
      case 'googleMeetRequest':
        return <GoogleMeetRequest employees={employees} />;
      case 'dataRequest':
        return <DataRequest employees={employees} />;
      case 'leaveStatus':
        return <LeaveStatus employees={employees} />;
      case 'messageBox':
        return <MessageBox employees={employees} onSendMessage={handleSendMessage} />;
      default:
        return <Dashboard employees={employees} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans flex flex-col lg:flex-row">
      {/* Tailwind CSS CDN */}
      <script src="https://cdn.tailwindcss.com"></script>
      {/* Font Inter */}
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
      <style>
        {`
          body {
            font-family: 'Inter', sans-serif;
          }
        `}
      </style>

      {/* Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-teal-800 text-white shadow-lg p-4 flex-shrink-0 lg:h-screen lg:overflow-y-auto">
        <div className="text-2xl font-bold mb-6 text-center text-teal-100">Super Admin</div>
        <nav>
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.component}>
                <button
                  onClick={() => setCurrentPage(item.component)}
                  className={`w-full text-left py-2 px-4 rounded-md transition-colors duration-200
                    ${currentPage === item.component ? 'bg-teal-600 text-white shadow-inner' : 'hover:bg-teal-700 hover:text-teal-100'}
                  `}
                >
                  {item.name}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 lg:p-8 overflow-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 capitalize">{currentPage.replace(/([A-Z])/g, ' $1').trim()}</h1>
        {/* Custom Message Box */}
        {message && (
          <div className="fixed top-4 right-4 bg-blue-500 text-white p-4 rounded-lg shadow-lg z-50 flex items-center justify-between">
            <span>{message}</span>
            <button onClick={() => setMessage('')} className="ml-4 text-white font-bold text-xl">&times;</button>
          </div>
        )}
        {renderPage()}
      </main>
    </div>
  );
}

export default App;
