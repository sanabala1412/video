import React, { useState } from 'react';

// Dummy Data (necessary for the AdminDashboard to function)
const dummyEmployees = [
  {
    id: 'emp001',
    name: 'Alice Johnson',
    email: 'alice.j@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 09:00 AM', '2025-07-14 06:00 PM'],
    logoutTimes: ['2025-07-14 05:00 PM', '2025-07-14 06:30 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-001',
    isIntern: false,
    birthday: '1990-08-15',
    workSchedule: 'Mon-Fri, 9 AM - 5 PM',
    leaveStatus: 'Approved (2 days)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Welcome to the team!', timestamp: '2025-07-01 10:00 AM' },
    ],
  },
  {
    id: 'emp002',
    name: 'Bob Williams',
    email: 'bob.w@example.com',
    status: 'Inactive',
    loginTimes: ['2025-07-10 08:30 AM'],
    logoutTimes: ['2025-07-10 04:30 PM'],
    attendance: { '2025-07-14': 'Absent', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-002',
    isIntern: true,
    birthday: '2000-03-22',
    workSchedule: 'Mon-Fri, 10 AM - 6 PM',
    leaveStatus: 'Pending (1 day)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Please submit your report.', timestamp: '2025-07-12 02:00 PM' },
    ],
  },
  {
    id: 'emp003',
    name: 'Charlie Brown',
    email: 'charlie.b@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 09:15 AM'],
    logoutTimes: ['2025-07-14 05:15 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-003',
    isIntern: false,
    birthday: '1995-11-01',
    workSchedule: 'Mon-Fri, 9 AM - 5 PM',
    leaveStatus: 'None',
    messages: [],
  },
  {
    id: 'emp004',
    name: 'Diana Prince',
    email: 'diana.p@example.com',
    status: 'Active',
    loginTimes: ['2025-07-14 08:45 AM'],
    logoutTimes: ['2025-07-14 04:45 PM'],
    attendance: { '2025-07-14': 'Present', '2025-07-13': 'Present' },
    salaryInvoice: 'INV-2025-07-004',
    isIntern: true,
    birthday: '2001-01-20',
    workSchedule: 'Mon-Fri, 9:30 AM - 5:30 PM',
    leaveStatus: 'Approved (5 days)',
    messages: [
      { id: 1, sender: 'Admin', text: 'Internship certificate ready for collection.', timestamp: '2025-07-10 11:00 AM' },
    ],
  },
];

const dummyInterviews = [
  {
    id: 'int001',
    candidateName: 'Eve Adams',
    position: 'Software Engineer',
    date: '2025-07-20',
    time: '10:00 AM',
    interviewer: 'Alice Johnson',
    status: 'Scheduled',
  },
  {
    id: 'int002',
    candidateName: 'Frank White',
    position: 'UX Designer',
    date: '2025-07-21',
    time: '02:00 PM',
    interviewer: 'Charlie Brown',
    status: 'Scheduled',
  },
  {
    id: 'int003',
    candidateName: 'Grace Lee',
    position: 'Project Manager',
    date: '2025-07-22',
    time: '11:00 AM',
    interviewer: 'Diana Prince',
    status: 'Pending',
  },
];

// Reusable Card Component
const Card = ({ title, children }) => (
  <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
    <h3 className="text-xl font-semibold text-gray-800 mb-4">{title}</h3>
    {children}
  </div>
);

// Employee Details Component
const EmployeeDetails = ({ employees }) => (
  <Card title="All Employee Details">
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg overflow-hidden">
        <thead className="bg-teal-700 text-white">
          <tr>
            <th className="py-3 px-4 text-left">ID</th>
            <th className="py-3 px-4 text-left">Name</th>
            <th className="py-3 px-4 text-left">Email</th>
            <th className="py-3 px-4 text-left">Status</th>
            <th className="py-3 px-4 text-left">Intern</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
              <td className="py-3 px-4">{emp.id}</td>
              <td className="py-3 px-4">{emp.name}</td>
              <td className="py-3 px-4">{emp.email}</td>
              <td className={`py-3 px-4 font-medium ${emp.status === 'Active' ? 'text-green-600' : 'text-red-600'}`}>
                {emp.status}
              </td>
              <td className="py-3 px-4">{emp.isIntern ? 'Yes' : 'No'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

// Attendance Component
const Attendance = ({ employees }) => {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  return (
    <Card title="Daily Attendance">
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-lg overflow-hidden">
          <thead className="bg-teal-700 text-white">
            <tr>
              <th className="py-3 px-4 text-left">Employee Name</th>
              <th className="py-3 px-4 text-left">Date</th>
              <th className="py-3 px-4 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((emp) => (
              <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
                <td className="py-3 px-4">{emp.name}</td>
                <td className="py-3 px-4">{today}</td>
                <td className={`py-3 px-4 font-medium ${emp.attendance[today] === 'Present' ? 'text-green-600' : 'text-red-600'}`}>
                  {emp.attendance[today] || 'N/A'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

// Invoice of Salary Component
const SalaryInvoice = ({ employees }) => (
  <Card title="Salary Invoices">
    {employees.map((emp) => (
      <div key={emp.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
        <h4 className="font-semibold text-gray-700">{emp.name} ({emp.id})</h4>
        <p className="text-sm text-gray-600"><strong>Invoice ID:</strong> {emp.salaryInvoice || 'N/A'}</p>
        <button className="mt-2 bg-cyan-500 text-white py-1 px-3 rounded-md text-sm hover:bg-cyan-600 transition-colors duration-200">
          View Invoice
        </button>
      </div>
    ))}
  </Card>
);

// Certificate for Intern Component
const InternCertificate = ({ employees }) => {
  const interns = employees.filter(emp => emp.isIntern);
  return (
    <Card title="Intern Certificates">
      {interns.length > 0 ? (
        interns.map((intern) => (
          <div key={intern.id} className="mb-4 p-3 border border-gray-200 rounded-md bg-gray-50">
            <h4 className="font-semibold text-gray-700">{intern.name} ({intern.id})</h4>
            <p className="text-sm text-gray-600">Internship Period: Jan 2025 - Jul 2025</p>
            <button className="mt-2 bg-cyan-500 text-white py-1 px-3 rounded-md text-sm hover:bg-cyan-600 transition-colors duration-200">
              Generate Certificate
            </button>
          </div>
        ))
      ) : (
        <p className="text-gray-600">No interns found.</p>
      )}
    </Card>
  );
};

// Leave Status Component
const LeaveStatus = ({ employees }) => (
  <Card title="Employee Leave Status">
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg overflow-hidden">
        <thead className="bg-teal-700 text-white">
          <tr>
            <th className="py-3 px-4 text-left">Employee Name</th>
            <th className="py-3 px-4 text-left">Leave Status</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
              <td className="py-3 px-4">{emp.name}</td>
              <td className={`py-3 px-4 font-medium ${emp.leaveStatus.includes('Approved') ? 'text-green-600' : emp.leaveStatus.includes('Pending') ? 'text-yellow-600' : 'text-gray-600'}`}>
                {emp.leaveStatus || 'N/A'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

// Interview Schedule Component
const InterviewSchedule = ({ interviews }) => (
  <Card title="Interview Schedule">
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white rounded-lg overflow-hidden">
        <thead className="bg-teal-700 text-white">
          <tr>
            <th className="py-3 px-4 text-left">Candidate</th>
            <th className="py-3 px-4 text-left">Position</th>
            <th className="py-3 px-4 text-left">Date</th>
            <th className="py-3 px-4 text-left">Time</th>
            <th className="py-3 px-4 text-left">Interviewer</th>
            <th className="py-3 px-4 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {interviews.map((interview) => (
            <tr key={interview.id} className="border-b border-gray-200 hover:bg-teal-50 transition-colors duration-200">
              <td className="py-3 px-4">{interview.candidateName}</td>
              <td className="py-3 px-4">{interview.position}</td>
              <td className="py-3 px-4">{interview.date}</td>
              <td className="py-3 px-4">{interview.time}</td>
              <td className="py-3 px-4">{interview.interviewer}</td>
              <td className={`py-3 px-4 font-medium ${interview.status === 'Scheduled' ? 'text-blue-600' : 'text-yellow-600'}`}>
                {interview.status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

// Add New Employee Component (Admin Only)
const AddNewEmployee = ({ onAddEmployeeRequest }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [position, setPosition] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name && email && position) {
      onAddEmployeeRequest({ name, email, position });
      setName('');
      setEmail('');
      setPosition('');
    }
  };

  return (
    <Card title="Add New Employee & Request Super Admin Approval">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="newName" className="block text-sm font-medium text-gray-700 mb-1">Employee Name:</label>
          <input
            type="text"
            id="newName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="e.g., John Doe"
            required
          />
        </div>
        <div>
          <label htmlFor="newEmail" className="block text-sm font-medium text-gray-700 mb-1">Employee Email:</label>
          <input
            type="email"
            id="newEmail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="e.g., john.doe@example.com"
            required
          />
        </div>
        <div>
          <label htmlFor="newPosition" className="block text-sm font-medium text-gray-700 mb-1">Position:</label>
          <input
            type="text"
            id="newPosition"
            value={position}
            onChange={(e) => setPosition(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm"
            placeholder="e.g., Marketing Specialist"
            required
          />
        </div>
        <button
          type="submit"
          className="w-full bg-teal-700 text-white py-2 px-4 rounded-md hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
        >
          Submit for Super Admin Approval
        </button>
      </form>
    </Card>
  );
};

// Dashboard Component (Common for both, can be customized per role if needed)
const Dashboard = ({ employees }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <Card title="Total Employees">
      <p className="text-5xl font-bold text-teal-600">{employees.length}</p>
    </Card>
    <Card title="Active Employees">
      <p className="text-5xl font-bold text-green-600">
        {employees.filter(emp => emp.status === 'Active').length}
      </p>
    </Card>
    <Card title="Interns">
      <p className="text-5xl font-bold text-purple-600">
        {employees.filter(emp => emp.isIntern).length}
      </p>
    </Card>
    <Card title="Attendance Today">
      <p className="text-5xl font-bold text-yellow-600">
        {employees.filter(emp => emp.attendance[new Date().toISOString().slice(0, 10)] === 'Present').length} / {employees.length}
      </p>
    </Card>
    <Card title="Pending Leaves">
      <p className="text-5xl font-bold text-red-600">
        {employees.filter(emp => emp.leaveStatus.includes('Pending')).length}
      </p>
    </Card>
    <Card title="Recent Activity">
      <ul className="list-disc pl-5 text-gray-700">
        <li>Alice Johnson logged in.</li>
        <li>Bob Williams updated status.</li>
        <li>New leave request from Charlie Brown.</li>
      </ul>
    </Card>
  </div>
);

// Custom Message Box Component
const CustomMessageBox = ({ message, onClose }) => {
  if (!message) return null;
  return (
    <div className="fixed top-4 right-4 bg-blue-500 text-white p-4 rounded-lg shadow-lg z-50 flex items-center justify-between">
      <span>{message}</span>
      <button onClick={onClose} className="ml-4 text-white font-bold text-xl">&times;</button>
    </div>
  );
};

// Admin Main Dashboard Component
const App = () => { // Removed props here, managing state internally
  const [employees, setEmployees] = useState(dummyEmployees); // Initialize state
  const [interviews, setInterviews] = useState(dummyInterviews); // Initialize state
  const [currentAdminPage, setCurrentAdminPage] = useState('dashboard');
  const [message, setMessage] = useState(''); // State for custom message box

  // Function to show a message
  const showMessage = (msg) => {
    setMessage(msg);
    setTimeout(() => setMessage(''), 3000); // Hide message after 3 seconds
  };

  // Dummy function for add employee request
  const handleAddEmployeeRequest = (newEmployeeData) => {
    console.log('New employee request submitted to Super Admin:', newEmployeeData);
    showMessage(`New employee request for ${newEmployeeData.name} submitted for Super Admin approval.`);
  };

  // Dummy function for logout
  const handleLogout = () => {
    showMessage('Logged out from Admin Dashboard!');
    // In a real app, this would redirect to a login page or clear authentication tokens
  };

  const adminNavItems = [
    { name: 'Dashboard', component: 'dashboard' },
    { name: 'Employee Details', component: 'employeeDetails' },
    { name: 'Interview Schedule', component: 'interviewSchedule' },
    { name: 'Leave Status', component: 'leaveStatus' },
    { name: 'Attendance', component: 'attendance' },
    { name: 'Salary Invoice', component: 'salaryInvoice' },
    { name: 'Intern Certificate', component: 'internCertificate' },
    { name: 'Add New Employee', component: 'addNewEmployee' },
  ];

  const renderAdminPage = () => {
    switch (currentAdminPage) {
      case 'dashboard':
        return <Dashboard employees={employees} />;
      case 'employeeDetails':
        return <EmployeeDetails employees={employees} />;
      case 'interviewSchedule':
        return <InterviewSchedule interviews={interviews} />;
      case 'leaveStatus':
        return <LeaveStatus employees={employees} />;
      case 'attendance':
        return <Attendance employees={employees} />;
      case 'salaryInvoice':
        return <SalaryInvoice employees={employees} />;
      case 'internCertificate':
        return <InternCertificate employees={employees} />;
      case 'addNewEmployee':
        return <AddNewEmployee onAddEmployeeRequest={handleAddEmployeeRequest} />;
      default:
        return <Dashboard employees={employees} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans flex flex-col lg:flex-row">
      {/* Tailwind CSS CDN */}
      <script src="https://cdn.tailwindcss.com"></script>
      {/* Font Inter */}
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
      <style>
        {`
          body {
            font-family: 'Inter', sans-serif;
          }
        `}
      </style>

      {/* Admin Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-teal-800 text-white shadow-lg p-4 flex-shrink-0 lg:h-screen lg:overflow-y-auto">
        <div className="text-2xl font-bold mb-6 text-center text-teal-100">Admin Panel</div>
        <nav>
          <ul className="space-y-2">
            {adminNavItems.map((item) => (
              <li key={item.component}>
                <button
                  onClick={() => setCurrentAdminPage(item.component)}
                  className={`w-full text-left py-2 px-4 rounded-md transition-colors duration-200
                    ${currentAdminPage === item.component ? 'bg-teal-600 text-white shadow-inner' : 'hover:bg-teal-700 hover:text-teal-100'}
                  `}
                >
                  {item.name}
                </button>
              </li>
            ))}
          </ul>
        </nav>
        <div className="mt-8">
          <button
            onClick={handleLogout}
            className="w-full bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors duration-200 shadow-md"
          >
            Logout
          </button>
        </div>
      </aside>

      {/* Admin Main Content Area */}
      <main className="flex-1 p-6 lg:p-8 overflow-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 capitalize">{currentAdminPage.replace(/([A-Z])/g, ' $1').trim()}</h1>
        <CustomMessageBox message={message} onClose={() => setMessage('')} />
        {renderAdminPage()}
      </main>
    </div>
  );
};

export default App;
