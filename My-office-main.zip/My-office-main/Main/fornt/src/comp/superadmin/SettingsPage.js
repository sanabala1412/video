import React from 'react';

function SettingsPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">⚙️ Settings</h1>
      <p>This is the settings page. Allow user to configure preferences here.</p>
    </div>
  );
}

export default SettingsPage;
