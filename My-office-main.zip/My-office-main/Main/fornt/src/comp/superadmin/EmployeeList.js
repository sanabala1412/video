import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/EmployeeList.css';

const employees = [
  { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Frontend Developer' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Backend Developer' },
  { id: 3, name: 'Alice Brown', email: 'alice@example.com', role: 'QA Engineer' }
];

const EmployeeList = () => {
  const navigate = useNavigate();

  return (
    <div className="employee-list">
      <h2>👥 Employee Details</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>{emp.name}</td>
              <td>{emp.email}</td>
              <td>{emp.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="back-btn" onClick={() => navigate('/')}>← Back to Dashboard</button>
    </div>
  );
};

export default EmployeeList;
