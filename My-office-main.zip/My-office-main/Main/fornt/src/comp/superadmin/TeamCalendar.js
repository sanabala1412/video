import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import '../styles/TeamCalendar.css';

const localizer = momentLocalizer(moment);

function TeamCalendar() {
  const [events, setEvents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [note, setNote] = useState('');
  const [showModal, setShowModal] = useState(false);

  const handleGenerateMeet = () => {
    const meetLink = 'https://meet.google.com/new';
    window.open(meetLink, '_blank');
    const newEvent = {
      id: events.length + 1,
      title: 'Google Meet Session',
      start: new Date(),
      end: moment().add(1, 'hour').toDate(),
      type: 'meeting',
      meetLink,
    };
    setEvents([...events, newEvent]);
  };

  const handleSelectSlot = (slotInfo) => {
    setSelectedDate(slotInfo.start);
    setShowModal(true);
  };

  const handleNoteSubmit = () => {
    if (!note.trim()) return;
    const newEvent = {
      id: events.length + 1,
      title: `📌 Reminder: ${note}`,
      start: selectedDate,
      end: moment(selectedDate).add(30, 'minutes').toDate(),
      type: 'reminder',
    };
    setEvents([...events, newEvent]);
    setShowModal(false);
    setNote('');
    alert(`✅ Reminder sent to employee: "${note}" on ${moment(selectedDate).format("DD MMM YYYY")}`);
  };

  return (
    <div className="calendar-container">
      <h2>📅 Team Calendar</h2>

      <button className="generate-btn" onClick={handleGenerateMeet}>
        📡 Generate Google Meet
      </button>

      <Calendar
        localizer={localizer}
        events={events}
        selectable
        onSelectSlot={handleSelectSlot}
        startAccessor="start"
        endAccessor="end"
        style={{ height: 500, marginTop: '20px' }}
      />

      {/* Modal for notes */}
      {showModal && (
        <div className="modal">
          <div className="modal-box">
            <h3>Set Reminder Note</h3>
            <textarea
              rows={4}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Enter your note here..."
            />
            <div className="modal-actions">
              <button onClick={handleNoteSubmit}>📤 Send Reminder</button>
              <button onClick={() => setShowModal(false)}>❌ Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div className="history-section">
        <h3>📜 Meeting & Reminder History</h3>
        <ul>
          {events.map((event) => (
            <li key={event.id}>
              <strong>{event.title}</strong> —{' '}
              {moment(event.start).format('DD MMM YYYY, hh:mm A')}
              {event.meetLink && (
                <>
                  <br />
                  <a href={event.meetLink} target="_blank" rel="noopener noreferrer">🔗 Open Meeting</a>
                </>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default TeamCalendar;
