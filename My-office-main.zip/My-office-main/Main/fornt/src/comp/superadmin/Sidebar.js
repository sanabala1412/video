import React from 'react';
import { Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Calendar,
  ClipboardList,
  FileText,
  Megaphone,
  Video,
  User,
  Settings
} from 'lucide-react';
import '../styles/Sidebar.css'; // Be sure this CSS exists

function Sidebar() {
  return (
    <div className="sidebar">
      {/* Top section */}
      <div className="sidebar-top">
        <h2 className="sidebar-title">Team Lead</h2>
        <ul className="sidebar-menu">
          <li>
            <LayoutDashboard size={20} />
            <Link to="/">Dashboard</Link>
          </li>
          <li>
            <Calendar size={20} />
            <Link to="/calendar">Calendar</Link>
          </li>
          <li>
            <ClipboardList size={20} />
            <Link to="/tasks">Assign Tasks</Link>
          </li>
          <li>
            <FileText size={20} />
            <Link to="/reports">Reports</Link>
          </li>
          <li>
            <Megaphone size={20} />
            <Link to="/announcements">Announcements</Link>
          </li>
          <li>
            <Video size={20} />
            <Link to="/gmeet">Google Meet</Link>
          </li>
        </ul>
      </div>

      {/* Bottom section */}
      <div className="sidebar-bottom">
        <div className="sidebar-icon">
          <User size={20} />
          <Link to="/profile">Profile</Link>
        </div>
        <div className="sidebar-icon">
          <Settings size={20} />
          <Link to="/settings">Settings</Link>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;
