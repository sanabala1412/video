// src/components/Announcements.js
import React from 'react';

function Announcements() {
  return (
    <div className="dashboard">
      <h1>📢 Announcements</h1>
      <p>Post updates for your team here.</p>
    </div>
  );
}

export default Announcements;
