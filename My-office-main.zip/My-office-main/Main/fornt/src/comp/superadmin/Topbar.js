import React from 'react';
import { Settings } from 'lucide-react';
import ProfileDropdown from './ProfileDropdown';
import '../styles/Topbar.css';

function Topbar() {
  return (
    <div className="topbar-fixed">
      <Settings className="cursor-pointer text-black hover:text-gray-600" title="Settings" size={26} />
      <ProfileDropdown />
    </div>
  );
}

export default Topbar;
