import React from 'react';
import { useNavigate } from 'react-router-dom';

const Reports = () => {
  const navigate = useNavigate();

  return (
    <div style={{ padding: '30px', textAlign: 'center' }}>
      <h2>📄 Reports</h2>
      <p>No pending reports available.</p>
      <p>"Stay updated and in sync. Timely submissions help the team grow stronger."</p>
      <button onClick={() => navigate('/')}>← Back to Dashboard</button>
    </div>
  );
};

export default Reports;
