import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/MainLayout.css';
import '../styles/Dashboard.css';

function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="dashboard">
      <h1 className="text-2xl font-bold mb-6">📊 Team Lead Dashboard</h1>
      <div className="stats-cards grid grid-cols-2 md:grid-cols-4 gap-6">
        <div
          className="card bg-white rounded-xl p-6 shadow hover:bg-gray-100 cursor-pointer"
          onClick={() => navigate('/employees')}
        >
          <div className="text-3xl">👥</div>
          <div className="text-lg mt-2 font-semibold">Employees: 6</div>
        </div>
        <div
          className="card bg-white rounded-xl p-6 shadow hover:bg-gray-100 cursor-pointer"
          onClick={() => navigate('/reports')}
        >
          <div className="text-3xl">📄</div>
          <div className="text-lg mt-2 font-semibold">Pending Reports: 2</div>
        </div>
        <div
          className="card bg-white rounded-xl p-6 shadow hover:bg-gray-100 cursor-pointer"
          onClick={() => navigate('/meetings')}
        >
          <div className="text-3xl">📅</div>
          <div className="text-lg mt-2 font-semibold">Meetings: 4</div>
        </div>
        <div
          className="card bg-white rounded-xl p-6 shadow hover:bg-gray-100 cursor-pointer"
          onClick={() => navigate('/tasks')}
        >
          <div className="text-3xl">📌</div>
          <div className="text-lg mt-2 font-semibold">Tasks This Week: 8</div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
