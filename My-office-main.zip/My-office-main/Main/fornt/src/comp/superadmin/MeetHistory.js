import React from 'react';
import { useNavigate } from 'react-router-dom';

const Meetings = () => {
  const navigate = useNavigate();

  return (
    <div style={{ padding: '30px', textAlign: 'center' }}>
      <h2>📅 Meetings</h2>
      <p>No meetings scheduled yet.</p>
      <button onClick={() => navigate('/')}>← Back to Dashboard</button>
    </div>
  );
};

export default Meetings;
