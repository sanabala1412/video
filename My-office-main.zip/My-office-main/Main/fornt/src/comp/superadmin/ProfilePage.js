import React from 'react';

function ProfilePage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">👤 Profile</h1>
      <p>This is the profile page. Display user info here.</p>
    </div>
  );
}

export default ProfilePage;
