import React from 'react';

const TaskAssignment = () => {
  return (
    <div style={{ padding: '30px', textAlign: 'center' }}>
      <h2>✍️ Assign New Task</h2>
      <p>Task assignment functionality coming soon.</p>
    </div>
  );
};

export default TaskAssignment;
