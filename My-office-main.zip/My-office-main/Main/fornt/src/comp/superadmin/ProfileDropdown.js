import React, { useState } from 'react';
import { UserCircle2, LogOut } from 'lucide-react';

function ProfileDropdown() {
  const [open, setOpen] = useState(false);

  const user = {
    name: 'John TL',
    email: 'john@myoffice.com',
  };

  return (
    <div className="relative">
      <UserCircle2
        className="cursor-pointer text-black hover:text-gray-600"
        onClick={() => setOpen(!open)}
        size={28}
      />
      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded shadow-lg py-2 z-50">
          <div className="px-4 py-2 border-b">
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>
          <button
            onClick={() => alert('Logout clicked')}
            className="w-full flex items-center gap-2 px-4 py-2 hover:bg-gray-100"
          >
            <LogOut size={18} /> Logout
          </button>
        </div>
      )}
    </div>
  );
}

export default ProfileDropdown;
