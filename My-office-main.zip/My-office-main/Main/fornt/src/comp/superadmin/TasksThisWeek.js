import React from 'react';
import { useNavigate } from 'react-router-dom';

const TasksThisWeek = () => {
  const navigate = useNavigate();

  return (
    <div style={{ padding: '30px', textAlign: 'center' }}>
      <h2>📌 Tasks This Week</h2>
      <p>No tasks assigned this week.</p>
      <button
        onClick={() => navigate('/tasks')}
        style={{
          padding: '10px 20px',
          backgroundColor: '#28a745',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          marginTop: '20px',
          cursor: 'pointer'
        }}
      >
        ➕ Assign Task
      </button>
      <br />
      <button
        onClick={() => navigate('/')}
        style={{
          marginTop: '15px',
          padding: '8px 16px',
          backgroundColor: '#6c757d',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer'
        }}
      >
        ← Back to Dashboard
      </button>
    </div>
  );
};

export default TasksThisWeek;
