import React, { useState } from 'react';

const LeaveRequest = () => {
  const [leave, setLeave] = useState({
    name: '',
    from: '',
    to: '',
    reason: ''
  });

  const handleChange = (e) => {
    setLeave({ ...leave, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Leave request submitted!");
    setLeave({ name: '', from: '', to: '', reason: '' });
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>📝 Submit Leave Request</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" value={leave.name} onChange={handleChange} required />
        <input name="from" type="date" value={leave.from} onChange={handleChange} required />
        <input name="to" type="date" value={leave.to} onChange={handleChange} required />
        <textarea name="reason" placeholder="Reason" value={leave.reason} onChange={handleChange} required />
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default LeaveRequest;
