import React, { useState } from 'react';
import './GMeetSection.css';

const GMeetSection = () => {
  const [link, setLink] = useState('');
  const [message, setMessage] = useState('');

  const generateLink = () => {
    const newLink = `https://meet.google.com/lookup/${Math.random().toString(36).substring(2, 10)}`;
    setLink(newLink);
    setMessage('Join the team meeting here 👇');
  };

  return (
    <div className="gmeet-section">
      <h2>📞 Generate Google Meet</h2>
      <button onClick={generateLink}>Generate Meeting</button>

      {link && (
        <div className="gmeet-message">
          <p>{message}</p>
          <a href={link} target="_blank" rel="noopener noreferrer">{link}</a>
        </div>
      )}
    </div>
  );
};

export default GMeetSection;
