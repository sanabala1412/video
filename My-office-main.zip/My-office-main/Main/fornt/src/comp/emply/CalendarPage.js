import React, { useEffect, useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';

function CalendarPage() {
  const [events, setEvents] = useState([]);
  const [showNote, setShowNote] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [noteText, setNoteText] = useState('');
  const [editEventId, setEditEventId] = useState(null);

  useEffect(() => {
    setEvents([
      { id: 1, title: "📦 Finish Module A", date: "2025-07-18" },
      { id: 2, title: "📞 Client Call", date: "2025-07-20" }
    ]);
  }, []);

  const handleDateClick = (arg) => {
    setSelectedDate(arg.dateStr);
    setNoteText('');
    setEditEventId(null);
    setShowNote(true);
  };

  const handleEventClick = (info) => {
    setSelectedDate(info.event.startStr);
    setNoteText(info.event.title.replace("📝 ", ""));
    setEditEventId(info.event.id);
    setShowNote(true);
  };

  const saveNote = () => {
    if (!noteText.trim()) return;
    if (editEventId) {
      // Edit existing event
      setEvents(
        events.map(event =>
          event.id === editEventId
            ? { ...event, title: `📝 ${noteText}`, date: selectedDate }
            : event
        )
      );
    } else {
      // Add new note
      const newId = Date.now();
      setEvents([...events, { id: newId, title: `📝 ${noteText}`, date: selectedDate }]);
    }
    setShowNote(false);
  };

  const deleteNote = () => {
    if (editEventId) {
      setEvents(events.filter(event => event.id !== editEventId));
    }
    setShowNote(false);
  };

  return (
    <div className="dashboard">
      <h1>🗓️ My Calendar</h1>
      <FullCalendar
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        events={events}
        editable={false}
        selectable={false}
        eventClick={handleEventClick}
        dateClick={handleDateClick}
        height="auto"
      />

      {showNote && (
        <div style={modalStyle}>
          <h3>{editEventId ? "Edit Note" : "Add Note"} for {selectedDate}</h3>
          <textarea
            rows="4"
            style={{ width: '100%', padding: '10px', borderRadius: '8px' }}
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Write your note here..."
          />
          <div style={{ marginTop: '10px' }}>
            <button onClick={saveNote} style={btnStyle}>Save</button>
            {editEventId && (
              <button onClick={deleteNote} style={{ ...btnStyle, backgroundColor: '#e74c3c' }}>Delete</button>
            )}
            <button onClick={() => setShowNote(false)} style={{ ...btnStyle, backgroundColor: '#ccc' }}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

const modalStyle = {
  position: 'fixed',
  top: '30%',
  left: '35%',
  width: '30%',
  background: 'white',
  padding: '20px',
  borderRadius: '10px',
  boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
  zIndex: 1000,
};

const btnStyle = {
  padding: '10px 20px',
  marginRight: '10px',
  border: 'none',
  borderRadius: '6px',
  backgroundColor: '#007bff',
  color: 'white',
  cursor: 'pointer'
};

export default CalendarPage;
