import React, { useEffect, useState } from 'react';
import '../styles/Notifications.css'; // Add this CSS file

function Notifications() {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    // Simulating a fetch from backend API
    setMessages([
      "📌 TL set a deadline for 2025-07-20: Submit report.",
      "📢 General update: Team meet at 4 PM."
    ]);

    // For empty state testing, set this:
    // setMessages([]);
  }, []);

  return (
    <div className="notifications-page">
      <h1>🔔 Notifications</h1>
      {messages.length === 0 ? (
        <div className="empty-state">
          <img
            src="https://cdn-icons-png.flaticon.com/512/4076/4076508.png"
            alt="No notifications"
          />
          <p>No notifications at the moment.</p>
        </div>
      ) : (
        <ul className="notifications-list">
          {messages.map((msg, i) => (
            <li key={i}>
              <span>{msg}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Notifications;
