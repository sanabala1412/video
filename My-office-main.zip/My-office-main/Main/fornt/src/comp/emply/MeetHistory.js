import React, { useState } from 'react';

function MeetHistory() {
  const [reason, setReason] = useState('');
  const [history, setHistory] = useState([]);

  const handleCreateMeet = () => {
    if (!reason.trim()) {
      alert("Please enter a valid reason.");
      return;
    }

    const newMeet = {
      date: new Date().toLocaleString(),
      link: "https://meet.google.com/new", // or generate one using Meet API later
      reason: reason
    };

    setHistory([newMeet, ...history]);
    setReason('');
    window.open(newMeet.link, "_blank");
  };

  return (
    <div className="dashboard">
      <h1>My Meet History</h1>

      <textarea
        placeholder="Enter reason for the meeting..."
        value={reason}
        onChange={(e) => setReason(e.target.value)}
      />
      <br />
      <button onClick={handleCreateMeet}>Create Google Meet</button>

      <div style={{ marginTop: "30px" }}>
        <h3>Meetings Created</h3>
        {history.length === 0 ? (
          <p>No meets created yet.</p>
        ) : (
          <ul>
            {history.map((meet, i) => (
              <li key={i}>
                🗓️ <strong>{meet.date}</strong><br />
                💬 Reason: {meet.reason}<br />
                🔗 <a href={meet.link} target="_blank" rel="noreferrer">Join</a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default MeetHistory;
