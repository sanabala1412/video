import React, { useState } from 'react';

function Settings() {
  const [name, setName] = useState("Sana Bala");
  const [email, setEmail] = useState("sana@example.com");
  const [phone, setPhone] = useState("9876543210");
  const [password, setPassword] = useState("");

  const handleSave = () => {
    alert("Settings updated successfully!");
    // TODO: Call backend to update details
  };

  return (
    <div className="dashboard">
      <h1>Account Settings</h1>

      <div className="settings-form">
        <label>Name:</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />

        <label>Email:</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />

        <label>Phone:</label>
        <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} />

        <label>New Password:</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />

        <button onClick={handleSave}>Save Changes</button>
      </div>
    </div>
  );
}

export default Settings;
