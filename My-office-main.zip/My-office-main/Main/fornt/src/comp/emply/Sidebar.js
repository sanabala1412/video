import React from 'react';
import { Link } from 'react-router-dom';
import { FiSettings } from 'react-icons/fi';
import { AiOutlineQuestionCircle } from 'react-icons/ai';

import '../styles/MainLayout.css';

function Sidebar() {
  return (
    <div className="sidebar">
      <h2>Employee Dashboard</h2>

      {/* Main Navigation */}
      <ul className="nav-links">
  <li><Link to="/calendar">My Calendar</Link></li>
  <li><Link to="/notifications">Notifications</Link></li>
  <li><Link to="/reports">Submit Report</Link></li>
  <li><Link to="/meet-history">Meet History</Link></li>
  <li><Link to="/leave-request">Leave Request</Link></li>
</ul>


      {/* Sidebar Footer Icons - SETTINGS & HELP */}
      <div className="sidebar-footer">
        <Link to="/settings" title="Settings">
          <FiSettings />
        </Link>
        <Link to="/help" title="Help">
          <AiOutlineQuestionCircle />
        </Link>
      </div>
    </div>
  );
}

export default Sidebar;
