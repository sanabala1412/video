import React, { useState, useEffect } from 'react';
import '../styles/ReportsPage.css';

function ReportsPage() {
  const [report, setReport] = useState('');
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [submittedReports, setSubmittedReports] = useState([]);

  useEffect(() => {
    // TODO: Replace with actual fetch from backend
    setSubmittedReports([
      { id: 1, text: 'Submitted project report', files: ['report1.pdf'] },
      { id: 2, text: 'Attended daily meeting', files: [] }
    ]);
  }, []);

  const handleFileChange = (e) => {
    setFiles([...e.target.files]);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setFiles([...files, ...Array.from(e.dataTransfer.files)]);
  };

  const handleSubmit = async () => {
    if (!report.trim() && files.length === 0) {
      setMessage('Please write a report or upload files.');
      return;
    }

    setLoading(true);
    setMessage('');

    try {
      const formData = new FormData();
      formData.append('report', report);
      files.forEach((file) => formData.append('files', file));

      const response = await fetch('http://localhost:8000/api/reports/', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        setMessage('✅ Report submitted successfully!');
        setReport('');
        setFiles([]);
        // TODO: Fetch updated list from backend
      } else {
        setMessage('❌ Failed to submit report.');
      }
    } catch (error) {
      setMessage('⚠️ Error submitting. Check your connection.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="report-page">
      <h1>📝 Submit Daily Report</h1>

      <textarea
        rows="4"
        placeholder="Write your report here..."
        value={report}
        onChange={(e) => setReport(e.target.value)}
        disabled={loading}
      />

      {/* File Upload Area */}
      <div
        className="drop-zone"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
      >
        <p>📎 Drag & Drop files here or click to browse</p>
        <input
          type="file"
          multiple
          accept=".pdf,.doc,.docx,.txt"
          onChange={handleFileChange}
          disabled={loading}
        />
      </div>

      {/* List Uploaded */}
      {files.length > 0 && (
        <ul className="selected-files">
          {files.map((f, i) => (
            <li key={i}>📄 {f.name}</li>
          ))}
        </ul>
      )}

      <button onClick={handleSubmit} disabled={loading}>
        {loading ? 'Submitting...' : 'Submit Report'}
      </button>

      {message && (
        <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
          {message}
        </div>
      )}

      {/* Previous Submissions */}
      <div className="submitted-section">
        <h3>📚 Previous Submissions</h3>
        {submittedReports.length === 0 ? (
          <div className="empty-state">
            <img
              src="https://cdn-icons-png.flaticon.com/512/4076/4076508.png"
              alt="No reports"
            />
            <p>No previous reports available.</p>
          </div>
        ) : (
          <ul className="submitted-reports">
            {submittedReports.map((r) => (
              <li key={r.id}>
                📝 {r.text}
                {r.files.length > 0 && (
                  <ul>
                    {r.files.map((f, i) => (
                      <li key={i}>📄 {f}</li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default ReportsPage;
