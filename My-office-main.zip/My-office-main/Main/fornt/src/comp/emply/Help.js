import React from 'react';

function Help() {
  return (
    <div className="dashboard">
      <h1>Help & Support</h1>

      <h3>Frequently Asked Questions</h3>
      <ul>
        <li>❓ <strong>How to submit a report?</strong><br />Go to "Submit Report" and type your daily update.</li>
        <li>❓ <strong>How to request leave?</strong><br />Use the "Leave Request" tab in the sidebar.</li>
        <li>❓ <strong>Who to contact for technical issues?</strong><br />Email <a href="mailto:support@myoffice.com">support@myoffice.com</a></li>
      </ul>

      <h3 style={{ marginTop: '30px' }}>Need More Help?</h3>
      <p>Email us at <a href="mailto:helpdesk@myoffice.com">helpdesk@myoffice.com</a> or talk to your TL.</p>
    </div>
  );
}

export default Help;
