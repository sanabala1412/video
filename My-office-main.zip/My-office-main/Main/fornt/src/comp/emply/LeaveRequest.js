import React, { useState, useEffect } from 'react';
import '../styles/LeaveRequest.css';

function LeaveRequest() {
  // All state variables properly declared
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [type, setType] = useState('Full Day');
  const [reason, setReason] = useState('');
  const [hours, setHours] = useState('');
  const [category, setCategory] = useState('General');
  const [days, setDays] = useState(0);
  const [isEmergency, setIsEmergency] = useState(false);
  const [attachment, setAttachment] = useState(null);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [requestExtraDays, setRequestExtraDays] = useState(false);
  const [extraDays, setExtraDays] = useState('');
  const [submittedLeaves, setSubmittedLeaves] = useState([]);
  const [approvalStage, setApprovalStage] = useState(null);

  // Calculate days between dates
  useEffect(() => {
    if (fromDate && toDate) {
      const start = new Date(fromDate);
      const end = new Date(toDate);
      const difference = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;
      setDays(difference > 0 ? difference : 1);
    } else if (fromDate && !toDate) {
      setDays(1);
    }
  }, [fromDate, toDate]);

  // Handle form submission
  const handleSubmit = () => {
    if (!fromDate || !reason || !acceptTerms) {
      alert("Please fill in all required fields and accept the terms.");
      return;
    }

    if (type === 'Custom Hours' && (!hours || isNaN(hours) || hours <= 0)) {
      alert("Please enter a valid number of hours.");
      return;
    }

    if (requestExtraDays && (!extraDays || isNaN(extraDays) || extraDays <= 0)) {
      alert("Please enter valid extra days.");
      return;
    }

    const leave = {
      id: Date.now(),
      from: fromDate,
      to: toDate || fromDate,
      reason,
      type,
      hours: type === 'Custom Hours' ? hours : null,
      days,
      extraDays: requestExtraDays ? extraDays : null,
      category,
      isEmergency,
      attachment: attachment ? attachment.name : null,
      approvalStage: 1 // starts from Team Lead Approval
    };

    setSubmittedLeaves([leave, ...submittedLeaves]);
    setFromDate('');
    setToDate('');
    setReason('');
    setType('Full Day');
    setHours('');
    setCategory('General');
    setIsEmergency(false);
    setAttachment(null);
    setAcceptTerms(false);
    setRequestExtraDays(false);
    setExtraDays('');
    setApprovalStage(1);
    alert("\u2705 Leave request submitted successfully!");
  };

  // Render approval tracker
  const renderTracker = (stage) => {
    const stages = ['Team Lead Approval', 'HR Approval', 'Admin Approval'];
    return (
      <div className="tracker-panel">
        <h4>Approval Tracker</h4>
        <ul className="tracker-list">
          {stages.map((s, i) => (
            <li
              key={i}
              className={`tracker-step ${stage > i ? 'approved' : stage === i + 1 ? 'current' : ''}`}
            >
              {s}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return (
    <div className="leave-container">
      <div className="leave-wrapper">
        <div className="leave-form-card">
          <div className="profile">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Employee" />
            <h2>Leave Request</h2>
          </div>

          <label>From Date:</label>
          <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />

          <label>To Date:</label>
          <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} />

          <label>Leave Type:</label>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="Full Day">Full Day</option>
            <option value="Half Day">Half Day</option>
            <option value="Custom Hours">Custom Hours</option>
          </select>

          {type === 'Custom Hours' && (
            <>
              <label>Enter Hours:</label>
              <input
                type="number"
                min="1"
                max="8"
                placeholder="Enter number of hours"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
              />
            </>
          )}

          <label>
            <input
              type="checkbox"
              checked={requestExtraDays}
              onChange={() => {
                setRequestExtraDays(!requestExtraDays);
                if (!requestExtraDays === false) setExtraDays('');
              }}
            /> Request Extra Days
          </label>

          {requestExtraDays && (
            <>
              <label>How many extra days?</label>
              <input
                type="number"
                min="1"
                placeholder="Enter number of extra days"
                value={extraDays}
                onChange={(e) => setExtraDays(e.target.value)}
              />
            </>
          )}

          <label>Category:</label>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="General">General</option>
            <option value="Medical">Medical</option>
            <option value="Bereavement">Bereavement</option>
            <option value="Personal">Personal</option>
            <option value="Others">Others</option>
          </select>

          <label>Reason:</label>
          <textarea
            rows="3"
            placeholder="Explain your leave reason..."
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />

          <label>Total Days:</label>
          <input type="text" value={days} disabled />

          <div className="switch-container">
            <label className="switch">
              <input
                type="checkbox"
                checked={isEmergency}
                onChange={() => setIsEmergency(!isEmergency)}
              />
              <span className="slider"></span>
            </label>
            <span className="switch-label">Emergency Leave</span>
            {isEmergency && <span className="emergency-badge">EMERGENCY</span>}
          </div>

          <label>Attach Document:</label>
          <input
            type="file"
            onChange={(e) => setAttachment(e.target.files[0])}
            accept=".pdf,.doc,.docx,.jpg,.png"
          />
          {attachment && <p className="attached-file">📎 {attachment.name}</p>}

          <div className="terms">
            <input
              type="checkbox"
              id="terms"
              checked={acceptTerms}
              onChange={() => setAcceptTerms(!acceptTerms)}
            />
            <label htmlFor="terms">I acknowledge the leave policy and terms of usage.</label>
          </div>

          <button onClick={handleSubmit}>Submit Leave</button>
        </div>

        {approvalStage && renderTracker(approvalStage)}

        <div className="leave-history">
          <h3>Recent Leave Requests</h3>
          {submittedLeaves.length > 0 ? (
            <ul>
              {submittedLeaves.map(leave => (
                <li key={leave.id}>
                  <strong>{leave.from} to {leave.to || leave.from}</strong> - {leave.reason}
                  {leave.isEmergency && <span className="emergency-badge">EMERGENCY</span>}
                  <div>Status: {leave.approvalStage === 1 ? 'Pending' : leave.approvalStage === 2 ? 'HR Approved' : 'Fully Approved'}</div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="empty-history">
              <img src="https://cdn-icons-png.flaticon.com/512/4076/4076478.png" alt="No leaves" />
              <p>No leave requests submitted yet</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default LeaveRequest;