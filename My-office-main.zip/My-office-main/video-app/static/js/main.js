const socket = io();
let localStream, previewStream, peerConnection, roomId = "";
const servers = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

// UI Elements
const homePage = document.getElementById("homePage");
const waitingRoom = document.getElementById("waitingRoom");
const videoCallRoom = document.getElementById("videoCallRoom");
const previewVideo = document.getElementById("previewVideo");
const roomIdDisplay = document.getElementById("roomIdDisplay");
const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");

// Home Page: Create Room
document.getElementById("createRoomBtn").onclick = () => {
  roomId = Math.random().toString(36).substring(2, 8).toUpperCase();
  goToWaitingRoom(roomId);
};

// Home Page: Enter Room
document.getElementById("enterRoomBtn").onclick = () => {
  const input = document.getElementById("roomIdInput").value.trim();
  if (input) {
    roomId = input;
    goToWaitingRoom(roomId);
  }
};

function goToWaitingRoom(room) {
  homePage.style.display = "none";
  waitingRoom.style.display = "block";
  roomIdDisplay.textContent = "Room ID: " + room;
  navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
      previewStream = stream;
      previewVideo.srcObject = stream;
    });
}

// Waiting Room: Toggle Camera/Mic
let previewMicOn = true, previewCamOn = true;
document.getElementById("togglePreviewMic").onclick = () => {
  previewMicOn = !previewMicOn;
  if (previewStream) previewStream.getAudioTracks()[0].enabled = previewMicOn;
};
document.getElementById("togglePreviewCamera").onclick = () => {
  previewCamOn = !previewCamOn;
  if (previewStream) previewStream.getVideoTracks()[0].enabled = previewCamOn;
};

// Waiting Room: Join Now
document.getElementById("joinNowBtn").onclick = () => {
  waitingRoom.style.display = "none";
  videoCallRoom.style.display = "block";
  // Use previewStream for local video
  localStream = previewStream;
  localVideo.srcObject = localStream;
  socket.emit("join", { room: roomId });
  startPeerConnection(roomId);
};

function startPeerConnection(room) {
  peerConnection = new RTCPeerConnection(servers);
  localStream.getTracks().forEach(track => {
    peerConnection.addTrack(track, localStream);
  });
  peerConnection.ontrack = event => {
    remoteVideo.srcObject = event.streams[0];
  };
  peerConnection.onicecandidate = event => {
    if (event.candidate) {
      socket.emit("signal", { room, candidate: event.candidate });
    }
  };
  socket.on("signal", async data => {
    if (data.description) {
      await peerConnection.setRemoteDescription(data.description);
      if (data.description.type === "offer") {
        const answer = await peerConnection.createAnswer();
        await peerConnection.setLocalDescription(answer);
        socket.emit("signal", { room, description: peerConnection.localDescription });
      }
    } else if (data.candidate) {
      await peerConnection.addIceCandidate(data.candidate);
    }
  });
  peerConnection.createOffer()
    .then(offer => peerConnection.setLocalDescription(offer))
    .then(() => {
      socket.emit("signal", { room, description: peerConnection.localDescription });
    });
}

// Video Call: Toggle Camera/Mic
let micOn = true, camOn = true;

document.getElementById("toggleMic").onclick = () => {
  micOn = !micOn;
  localStream.getAudioTracks()[0].enabled = micOn;
};

document.getElementById("toggleCamera").onclick = () => {
  camOn = !camOn;
  localStream.getVideoTracks()[0].enabled = camOn;

  const cameraIcon = document.getElementById("cameraIcon");

  if (camOn) {
    localVideo.style.display = "block";
    cameraIcon.className = "fa fa-video icon";
    cameraIcon.style.color = "#fff";
  } else {
    localVideo.style.display = "none";
    cameraIcon.className = "fa fa-video-slash icon";
    cameraIcon.style.color = "#d32f2f";
  }
};

// Video Call: Screenshare
document.getElementById("screenshareBtn").onclick = async () => {
  const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
  const screenTrack = screenStream.getVideoTracks()[0];
  const sender = peerConnection.getSenders().find(s => s.track.kind === "video");
  if (sender) sender.replaceTrack(screenTrack);
  localVideo.srcObject = screenStream;
  screenTrack.onended = () => {
    sender.replaceTrack(localStream.getVideoTracks()[0]);
    localVideo.srcObject = localStream;
  };
};

// Video Call: End Call
document.getElementById("endCallBtn").onclick = () => {
  document.getElementById("videoCallRoom").style.display = "none";
  document.getElementById("rejoinModal").style.display = "flex";
};

// Rejoin Modal
document.getElementById("rejoinBtn").onclick = () => {
  const room = document.getElementById("rejoinRoomId").value.trim();
  if (room) {
    document.getElementById("rejoinModal").style.display = "none";
    document.getElementById("homePage").style.display = "none";
    document.getElementById("waitingRoom").style.display = "none";
    document.getElementById("videoCallRoom").style.display = "block";
    socket.emit("join", { room });
    startPeerConnection(room);
  }
};

// Rejoin Modal: Back to main page
document.getElementById("backBtn").onclick = () => {
  document.getElementById("rejoinModal").style.display = "none";
  document.getElementById("videoCallRoom").style.display = "none";
  document.getElementById("waitingRoom").style.display = "none";
  document.getElementById("homePage").style.display = "block";
};

// Full Screen: Toggle video window fullscreen
document.getElementById("fullscreenBtn").onclick = () => {
  const videoWindow = document.getElementById("videoWindow");
  if (!document.fullscreenElement) {
    if (videoWindow.requestFullscreen) {
      videoWindow.requestFullscreen();
    } else if (videoWindow.webkitRequestFullscreen) {
      videoWindow.webkitRequestFullscreen();
    } else if (videoWindow.msRequestFullscreen) {
      videoWindow.msRequestFullscreen();
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    }
  }
};

// Video Call: Chat
const messages = document.getElementById("messages");
document.getElementById("sendChatBtn").onclick = () => {
  const msg = document.getElementById("chatInput").value;
  if (msg) {
    socket.emit("signal", { room: roomId, chat: msg });
    addMessage("Me: " + msg);
    document.getElementById("chatInput").value = "";
  }
};
function addMessage(msg) {
  const div = document.createElement("div");
  div.textContent = msg;
  messages.appendChild(div);
}
socket.on("signal", data => {
  if (data.chat) addMessage("Peer: " + data.chat);
});
